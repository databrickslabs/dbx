from sklearn.preprocessing import MinMaxScaler

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import LSTM
from tensorflow.keras.preprocessing.sequence import TimeseriesGenerator

import mlflow
import mlflow.keras


class LSTMForecastingModel:
    def __init__(self):
        self.sequence_length = 31
        self.num_features = 1
        self.batch_size = 128
        self.number_of_epochs = 1
        self.initModel()

    def initModel(self):
        self.model = Sequential()
        self.model.add(LSTM(100, activation='relu', input_shape=(self.sequence_length, self.num_features)))
        self.model.add(Dense(1))
        self.model.compile(optimizer='adam', loss='mse')
        self.model.summary()

    def train(self, df):

        # we should build the list of all dates and merge it with date from logfood.
        # The logfood data does not contain zero rows in a case when there were no usage

        df['y'] = df['y'].cumsum()
        # df['ds'] = df['date']
        # full_df = df[['ds', 'y']].copy()
        full_df = df

        scaler = MinMaxScaler()
        full_df['y'] = scaler.fit_transform(full_df['y'].values.reshape(-1, 1))

        train_df = full_df.iloc[:-90]
        test_df = full_df.iloc[-90:]

        train_data = train_df['y'].values.reshape(-1, 1)
        train_generator = TimeseriesGenerator(train_data, train_data, length=self.sequence_length, sampling_rate=1,
                                              batch_size=self.batch_size)
        test_data = test_df['y'].values.reshape(-1, 1)
        if (len(test_data) < 31):
            return None, None
        test_generator = TimeseriesGenerator(test_data, test_data, length=self.sequence_length, sampling_rate=1,
                                             batch_size=self.batch_size)

        self.model.fit_generator(train_generator, validation_data=test_generator, epochs=self.number_of_epochs)

        self.metrics = {}
        self.metrics['val_loss'] = self.model.evaluate(test_generator)

        return self.metrics

    def log_model(self, name, accountId, experimentID):
        with mlflow.start_run(run_name="Candidate model - " + name, experiment_id=experimentID) as run:
            mlflow.keras.log_model(self.model, "model")
            for metric, value in self.metrics.items():
                mlflow.log_metric(metric, value)
            mlflow.set_tag("model_name", name)
            mlflow.set_tag("model_stage", "candidate")
            mlflow.set_tag("accountId", accountId)

    def load_models(self, accountId, experimentID):
        # load latest model from mlflow for given account
        pass

import pandas as pd

from pyspark.sql.functions import *
from pyspark.sql.types import *


from lstmforecasting.LSTMForecastingModel import LSTMForecastingModel


class LSTMForecasting:
    def __init__(self, experimentID):
        self.experimentID = experimentID

    def predictForecastingModelDistributed(self, sparkDF):
        # run predictions for latest models for each account
        # get result DF with  prediction of next day consumption for each account
        pass

    def trainForecastingModelDistributed(self, sparkDF):
        schema = StructType([
            StructField('AccountId', StringType()),
            StructField('val_loss', DoubleType())
        ])

        @pandas_udf(schema, PandasUDFType.GROUPED_MAP)
        def trainForecastingModelDistributed(pdf):
            accountId = str(pdf['AccountId'].iloc[0])

            model = LSTMForecastingModel()
            metrics = model.train(pdf)
            if metrics is not None:
                model.log_model('lstm-forecasting', accountId, self.experimentID)

            return pd.DataFrame({
                "AccountId": [accountId],
                "val_loss": [metrics['val_loss']]
            })

        df = sparkDF.groupBy("AccountId").apply(trainForecastingModelDistributed)
        return df

    def fit(self, df):
        return self

    def predict_pd(self, df):
        return df

    def predict(self, X):
        return X